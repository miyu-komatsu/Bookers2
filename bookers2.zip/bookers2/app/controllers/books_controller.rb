class BooksController < ApplicationController

  before_action :authenticate_user!

  def index
    @user = User.find(current_user.id)
    @Nbook = Book.new
    @books = Book.all
  end

  def show
    @book = Book.find(params[:id])
    @user = @book.user
    @Nbook = Book.new
  end

  def create
    @book = Book.new(book_params)
    @book.user_id = current_user.id
    if @book.save
      flash[:success] = '--- successfully ---'
      redirect_to book_path(@book)
    else
      @Nbook = Book.new
      @books = Book.all
      render :index
    end
  end

  def edit
    @book = Book.find(params[:id])

    unless @book.user == current_user
      redirect_to books_path
    end
  end

  def update
    @book = Book.find(params[:id])

    unless @book.user == current_user
      redirect_to books_path
    end

    @book = Book.find(params[:id])
    if @book.update(book_params)
      flash[:success] = '--- successfully ---'
      redirect_to book_path(@book)
    else
      render :edit
    end
  end

  def destroy
    @book = Book.find(params[:id])
    @book.destroy
    flash[:success] = '--- successfully ---' #同じでもOK
    redirect_to books_path #@book?
  end

  private

  def book_params
    params.require(:book).permit(:title, :body)
  end

end
